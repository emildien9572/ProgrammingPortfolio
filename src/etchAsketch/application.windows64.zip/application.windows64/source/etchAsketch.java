import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class etchAsketch extends PApplet {

// Global Variable
int x, y;

public void setup() {
  
  frameRate(10);
  x = 10;
  y = 10;
}

public void draw() {
  fill(0);
  strokeWeight(3);
  if (keyPressed) {
    if (key == 'd' || key == 'D') {
      moveRight(5);
    } else if (key == 'a' || key == 'A') {
      moveLeft(5);
    } else if (key == 'w' || key == 'W') {
      moveUp(5);
    } else if (key == 's' || key == 'S') {
      moveDown(5);
    }
  }
  //drawName();
  //noLoop();
}

public void mousePressed() {
  saveFrame("line-######.png");
}

public void keyPressed() {
  if (key == CODED) {
    if (keyCode == RIGHT) {
      moveRight(5);
    } else if (keyCode == LEFT) {
      moveLeft(5);
    } else if (keyCode == UP) {
      moveUp(5);
    } else if (keyCode == DOWN) {
      moveDown(5);
    }
  }
}

public void drawName() {
  //moveRight(50);
  //moveLeft(50);
  //moveDown(25);
  //moveRight(45);
  //moveLeft(45);
  //moveDown(25);
  //moveRight(60);
  //moveUp(50);
  //moveRightDown(25);
  //moveRightUp(25);
  //moveDown(50);
  //moveRight(35);
  //moveUp(50);
  //moveLeft(25);
  //moveRight(50);
  //moveLeft(25);
  //moveDown(50);
  //moveRight(35);
  //moveUp(50);
  //moveDown(50);
  //moveRight(60);
  //moveUp(25);
  //moveLeftUp(25);
  //moveRightDown(25);
  //moveRightUp(25);
  //moveLeftDown(25);
  //moveLeftUp(0);
  //moveLeftDown(0);
}

// Method to draw right lines
public void moveRight(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y);
  }
  x=x+rep;
}

// Method to draw lines down
public void moveDown(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y+i);
  }
  y=y+rep;
}

// Method to draw left lines
public void moveLeft(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y);
  }
  x=x-rep;
}

// Method to draw lines up
public void moveUp(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x, y-i);
  }
  y=y-rep;
}

//Method to draw right and down lines
public void moveRightDown(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y+i);
  }
  y=y+rep;
  x=x+rep;
}

// Method to draw right and up lines
public void moveRightUp(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x+i, y-i);
  }
  y=y-rep;
  x=x+rep;
}

// Method to draw left and up lines
public void moveLeftUp(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y-i);
  }
  y=y-rep;
  x=x-rep;
}

// Method to draw left and down
public void moveLeftDown(int rep) {
  for (int i = 0; i<rep; i++) {
    point(x-i, y+i);
  }
  y=y+rep;
  x=x-rep;
}
  public void settings() {  size(600, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "etchAsketch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
